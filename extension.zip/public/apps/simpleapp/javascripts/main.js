/****************************************************
* This file should load AFTER app.js or whichever .js file that defines the onReady, onViewer, onContext and onData functions
*
* Note:  This implmentation has been provided for convenience, developers are not required to use this pattern.
****************************************************/
var app = {
  NO_CONTEXT : "NO_CONTEXT",
  viewContext : { },
  actionContext : { },
  data : null,
  viewer : null,
  request : undefined,
  jive_user_id : [],
  cancelled : false,
  
  resize : function() {
    //console.log('resize');
    /*** DELAYED TO MAKE SURE DOM HAS SETTLED ***/
    setTimeout(function() {
      gadgets.window.adjustHeight();
      gadgets.window.adjustWidth();
    },200);
  },

  getCurrentView : function() {
    var currentView = location.href.substr(location.href.indexOf('view=')+'view='.length);
    currentView = currentView.substr(0,currentView.indexOf('&'));
    return currentView;
  },

  fireOnViewer : function() {
    if (onViewer && typeof onViewer === "function") {
      onViewer(this.viewer);
    } // end if
  }, // end function

  fireOnReady : function() {
    if (onReady && typeof onReady === "function") {
      onReady(opensocial.getEnvironment());
    } // end if
  }, // end function

  fireOnViewContext : function() {
    if (onView && typeof onView === "function") {
      /*** DATA CLEANSING ***/
      if (this.viewContext.object === app.NO_CONTEXT) {
        delete this.viewContext.object;
      } // end if
      onView(this.viewContext);
    } // end if
  }, // end function

  fireOnActionContext : function() {
    if (onAction && typeof onAction === "function") {
      /*** DATA CLEANSING ***/
      if (this.actionContext.object === app.NO_CONTEXT) {
        delete this.actionContext.object;
      } // end if
      onAction(this.actionContext);
    } // end if
  }, // end function

  fireOnDataContext : function() {
    if (onData && typeof onData === "function") {
      onData(this.data);
    } // end if
  }, // end function

  init : function() {
    // RESOLVE THE DATA CONTEXT (IF AVAILABLE)
    // NOTE: THIS WONT FIRE IF NOT PRESENT, SO CANT BE PART OF THE CONTEXT
    opensocial.data.getDataContext().registerListener('org.opensocial.ee.context',gadgets.util.makeClosure(this, this.handleDataContext));

    // RESOLVE THE VIEWER
    osapi.jive.corev3.people.getViewer().execute(gadgets.util.makeClosure(this, this.handleViewer));

    // RESOLVE THE VIEWER
    osapi.jive.core.container.getLaunchContext(gadgets.util.makeClosure(this, this.handleViewContext));

    /*** RESOLVE ANY ACTIONS DEFINED IN app.js > ACTION_IDS ***/
    var actionScope = this;
    function registerActionLoaders(actionIds) {
        for (id of actionIds) {
          gadgets.actions.updateAction({id:id, callback: gadgets.util.makeClosure(actionScope, actionScope.handleActionContext, id) });
        } // end for x
    } // end registerLoader

    if (ACTION_IDS && ACTION_IDS.constructor === Array && ACTION_IDS.length > 0) {
      registerActionLoaders(ACTION_IDS);
    } // end if

    this.fireOnReady();
  },

  /*** PROCESS THE VIEW CONTEXT ****/
  handleViewContext : function(context) {
    app.viewContext["currentView"] = app.getCurrentView();
    app.viewContext["params"] = gadgets.views.getParams();
    if (context) {
      osapi.jive.corev3.resolveContext(context,
        function(object) {
          app.viewContext["object"] = object["content"];

          app.fireOnViewContext();
      });
    } else {
      app.viewContext["object"] = app.NO_CONTEXT;
      app.fireOnViewContext();
    } // end if
  }, // end handleViewContext

  /*** PROCESS THE DATA CONTEXT ****/
  handleDataContext : function(key) {
    //console.log('handleDataContext',key);
    app.data = opensocial.data.getDataContext().getDataSet(key);
    app.fireOnDataContext();
  }, // end handleViewContext

  /*************************************************************************************
   * EXAMPLE GET CONTEXT FOR ACTION LINKS
   * NOTE:  YOU MUST INCLUDE THE coreapi-context-resolver-v3.js FILE or the "jive-core-v3-resolver" Feature in your app.xml FOR THIS TO WORK
   *************************************************************************************/
  handleActionContext : function(action,context) {
    //console.log('handleActionContext',action,context);
    app.actionContext["currentView"] = app.getCurrentView();
    app.actionContext["action"] = action;
    app.actionContext["params"] = gadgets.views.getParams();
    app.actionContext["isRTE"] = (context["jive"]["content"]["id"] === -1);
    if (context) {
      if (!app.actionContext["isRTE"]) {
        osapi.jive.corev3.resolveContext(context,
          function(object) {
            app.actionContext["object"] = object["content"];
            app.fireOnActionContext();
        });
      } else {
        app.actionContext["object"] = app.NO_CONTEXT;
        app.fireOnActionContext();
      } // end if
    } // end if
  }, // end handleActionContext

  handleViewer : function(viewer) {
    //console.log('handleViewer',viewer);
    app.viewer = viewer;
    app.fireOnViewer();
  }, // end handleViewer

  //foll stream inbox
  followStreamInbox : function(stream,x){
    if(stream.source === "connections"){
      var conType = stream.id;
      osapi.jive.core.post(
      {
          "v":"v3",
          "href":"/streams/"+conType+"/associations",
          "body":["/places/"+spaceVar.objectSpace.placeID]
      }).execute(function(response){
          if(response.error){ 
            var message = response.error.message;
            $("#alertFS").text("Error: "+message);
          }
          else {
            $("#alertFS").text("Completed Batch: "+x+" of "+spaceArrays.arrBatch.length);
            if(spaceArrays.arrBatch.length - 1 === x){
              $("#alertFS").text("Completed!");
            }
          }
      });
    }
  },
  //follow activity stream
  followStreamActivity : function(stream,x){
    if(stream.source === "communications"){
      var conTypeComms = stream.id;
      osapi.jive.core.post({
          "v":"v3",
          "href":"/streams/"+conTypeComms+"/associations",
          "body":["/places/"+spaceVar.objectSpace.placeID]
      }).execute(function(response){
          if(response.error){
            var message = response.error.message;
            $("#alertFS").text("Error: "+message); 
          }
          else{
            $("#alertFS").text("Completed Batch: "+x+" of "+spaceArrays.arrBatch.length);
            if(spaceArrays.arrBatch.length - 1 === x){
                $("#alertFS").text("Completed!");
            } 
          }
      });
    }
  },//end followStreamActivity
 
  //Get all people
  getAll : function (alert_msg){
    app.jive_user_id.length = 0;
    app.request = osapi.jive.corev3.people.getAll({fields:'@all',count:100});
    app.getPeople(app.request,alert_msg);
  },
  getPeople : function (request,alert_msg){
	  request.execute(function(response){
		  if(response.error){
        $(alert_msg).text(response.error.message);
      }
      else if( app.cancelled === true ){
        return app.jive_user_id;
      }
		  else if (!response.list){
			  $(alert_msg).text("Response is not a list!");
		  }
		  else{
        $(response.list).each(function(index,person){
          app.jive_user_id.push(person.id);
          $(alert_msg).text( "Adding employee : " + app.jive_user_id.length );
        });
        if (response.getNextPage){
            var requestNextPage = response.getNextPage();
            app.getPeople(requestNextPage,alert_msg);
        }
        if(!response.getNextPage){
            $(alert_msg).text( "People Successfuly Loaded: " + app.jive_user_id.length );
            var confirmed = confirm( "You are about to make all Hive users auto follow this group: "+ group.objectGroup.name +", are you sure?" );
            if( confirmed == true ){
              hiveArrays.folGrpId = app.jive_user_id;
              set_grp_auto_follow();
            }
            else{
              app.jive_user_id.length = 0;
              clear_checkbox();
            }
           
        }
      }
    });
  }
  //end function get all people
};
gadgets.util.registerOnLoadHandler(gadgets.util.makeClosure(app, app.init));
