// $(function(){
//     $("#toUFG").click(function()
//     {
//         // $("#menu").hide();
//         // $("#info").hide();
//         // $("#ufg").show();
//         window.open("make_group_public.html","_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=100,left=500,width=800,height=500");
//         app.resize();
//     });
// });
